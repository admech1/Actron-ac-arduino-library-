#include"arduino.h"
#include "Actronac.h"
#include <IRremote.h>

IRsend irsend;


Actronac::Actronac()
{}
void Actronac::acon (void)
{
  Serial.println("acon");
}
void Actronac::acoff(void)
{
  Serial.println("acoff");
}
void Actronac::heat (void)
{
  Serial.println("heat");
}
void Actronac::cool(void)
{
  Serial.println("cool");
}
void Actronac::dry (void)
{
  Serial.println("dry");
}
void Actronac::settemp17(void)
{
  Serial.println("settemp17");
}
void Actronac::settemp18 (void)
{
  Serial.println("settemp18");
}
void Actronac::settemp19(void)
{
  Serial.println("settemp19");
}
void Actronac::settemp20 (void)
{
  Serial.println("settemp20");
}
void Actronac::settemp21(void)
{
  Serial.println("settemp21");
}
void Actronac::settemp22 (void)
{
  Serial.println("settemp22");
}
void Actronac::settemp23(void)
{
  Serial.println("settemp23");
}
void Actronac::settemp24 (void)
{
  Serial.println("settemp24");
}
void Actronac::settemp25(void)
{
  Serial.println("settemp25");
}
void Actronac::settemp26 (void)
{
  Serial.println("settemp26");
}
void Actronac::settemp27(void)
{
  Serial.println("settemp27");
}
void Actronac::settemp28 (void)
{
  Serial.println("settemp28");
}
void Actronac::settemp29(void)
{
  Serial.println("settemp29");
}
void Actronac::settemp30 (void)
{
  Serial.println("settemp30");
}