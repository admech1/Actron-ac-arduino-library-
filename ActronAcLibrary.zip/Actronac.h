





#ifndef Actronac_h
#define Actronac_h
#include "arduino.h"

class Actronac 
{

  public:
  Actronac(void);

  void acon ();
  void acoff();
  void cool();
  void heat();
  void dry();
  void settemp17();
  void settemp18();
  void settemp19();
  void settemp20();
  void settemp21();
  void settemp22();
  void settemp23();
  void settemp24();
  void settemp25();
  void settemp26();
  void settemp27();
  void settemp28();
  void settemp29();
  void settemp30();
};








#endif
