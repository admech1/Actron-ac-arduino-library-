Library for Actron brand Air conditioner 
Requires IRremote library to work from ken shirrif